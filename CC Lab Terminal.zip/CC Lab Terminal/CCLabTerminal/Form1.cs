﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Collections;
using System.IO;
using System.Diagnostics.Eventing.Reader;

namespace CCLabTerminal
{
    
    public partial class Form1 : Form
    {
        int myCount = 0;
        string filepath = "D:\\Study Material\\7th Semester\\Compiler Construction\\Compiler Construction\\CC Lab Terminal\\sampleCode1.txt";
        Dictionary<string, string> productionRules = new Dictionary<string, string>();
        Dictionary<string, HashSet<string>> firstSets = new Dictionary<string, HashSet<string>>();
          Dictionary<string, HashSet<string>> followSets = new Dictionary<string, HashSet<string>>();

        int lineNo = 0;
        string[] row = null;
        int sumCount, subCount, mulCount, divCount, equalCount, greaterCount, lessCount, address = 0;

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
            richTextBox2.Text = "";

            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    richTextBox1.Text = "" +
                        "1) number -> number digit\n" +
                        "2) number -> digit\n" +
                        "3) digit -> 0\n" +
                        "4) digit -> 1\n" +
                        "5) digit -> 2\n" +
                        "6) digit -> 3\n" +
                        "7) digit -> 4\n" +
                        "8) digit -> 5\n" +
                        "9) digit -> 6\n" +
                        "10) digit -> 7\n" +
                        "11) digit -> 8\n" +
                        "12) digit -> 9";
                    richTextBox2.Text = "" +
                        "1) number1.val = (number2.val*10)+digit.val\n" +
                        "2) number.val = digit.val\n" +
                        "3) digit.val = 0\n" +
                        "4) digit.val = 1\n" +
                        "5) digit.val = 2\n" +
                        "6) digit.val = 3\n" +
                        "7) digit.val = 4\n" +
                        "8) digit.val = 5\n" +
                        "9) digit.val = 6\n" +
                        "10) digit.val = 7\n" +
                        "11) digit.val = 8\n" +
                        "12) digit.val = 9";
                    break;
                case 1:
                    richTextBox1.Text = "" +
                        "1) exp -> exp + term\n" +
                        "2) exp -> exp - term\n" +
                        "3) exp -> term\n" +
                        "4) term -> term * factor\n" +
                        "5) term -> factor\n" +
                        "6) factor -> ( exp )\n" +
                        "7) factor -> number";
                    richTextBox2.Text = "" +
                        "1) exp1.val = exp2.val + term.val\n" +
                        "2) exp1.val = exp2.val - term.val\n" +
                        "3) exp.val = term.val\n" +
                        "4) term1.val = term2.val*factor.val\n" +
                        "5) term.val = factor.val\n" +
                        "6) factor.val = exp.val\n" +
                        "7) factor.val = number.inval";
                    break;
                case 2:
                    richTextBox1.Text = "" +
                        "1) decl -> type var-list\n" +
                        "2) type -> int\n" +
                        "3) type -> float\n" +
                        "4) var-list -> id, var-list\n" +
                        "5) var-list -> id";
                    richTextBox2.Text = "" +
                        "1) var-list.dtype = type.dtype\n" +
                        "2) type.dtype = int\n" +
                        "3) type.dtype = float\n" +
                        "4) id.dtype = var-list1.dtype\n" +
                        "var-list2.dtype = var-list1.dtype\n" +
                        "5) id.dtype = var-list.dtype";
                    break;
                case 3:
                    richTextBox1.Text = "" +
                        "1) based-num -> num basechar\n" +
                        "2) basechar -> o\n" +
                        "3) basechar -> d\n" +
                        "4) num -> num digit\n" +
                        "5) num -> digit\n" +
                        "6) digit -> 0\n" +
                        "7) digit -> 1\n" +
                        "8) digit -> 2\n" +
                        "9) digit -> 3\n" +
                        "10) digit -> 4\n" +
                        "11) digit -> 5\n" +
                        "12) digit -> 6\n" +
                        "13) digit -> 7\n" +
                        "14) digit -> 8\n" +
                        "15) digit -> 9";
                    richTextBox2.Text = "" +
                        "1) based-num.val = num.val\n" +
                        "num.basee = basechar.basee" +
                        "2) basechar.basee = 8\n" +
                        "3) basechar.basee = 10\n" +
                        "4) if(digit.val == null || num2.val == null)\n" +
                        "num1.val = null\n" +
                        "else\n" +
                        "num1.val = (num2.val*num1.basee)+digit.val\n" +
                        "num2.basee = num1.basee\n" +
                        "digit.basee = num1.basee\n" +
                        "5) num.val = digit.val\n" +
                        "digit.basee = num.basee\n" +
                        "6) digit.val = 0\n" +
                        "7) digit.val = 1\n" +
                        "8) digit.val = 2\n" +
                        "9) digit.val = 3\n" +
                        "10) digit.val = 4\n" +
                        "11) digit.val = 5\n" +
                        "12) digit.val = 6\n" +
                        "13) digit.val = 7\n" +
                        "14) if(digit.basee == 8)\n" +
                        "digit.val = null\n" +
                        "else\n" +
                        "digit.val = 8\n" +
                        "15) if(digit.basee == 8)\n" +
                        "digit.val = null\n" +
                        "else\n" +
                        "digit.val = 9";
                    break;
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (!textBox1.Text.Trim().Equals(""))
            {
                String input = textBox1.Text.Trim();
                char[] chars = input.ToCharArray();
                List<NonTerminal> list = new List<NonTerminal>();

                switch (comboBox1.SelectedIndex)
                {
                    case 0:
                        Console.WriteLine("________________________________________________________");
                        //AppendToOutput("________________________________________________________");
                        list.Clear();
                        try
                        {
                            foreach (char ch in chars)
                            {
                                NonTerminal d = new NonTerminal(0);
                                string num_str = "" + ch;

                                d.val = int.Parse(num_str);
                                list.Add(d);
                            }
                        }
                        catch (FormatException)
                        {
                            MessageBox.Show("Incorrect Input", "ERROR",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                            break;
                        }
                        //list.Reverse();
                        int countVar = 0;
                        NonTerminal root = new NonTerminal(0);
                        root.val = list[0].val;
                        for (int i = 0; i < list.Count; i++)
                        {
                            AppendToOutput("digit.val = " + list[i].val);
                            countVar++;
                            if (countVar > 1)
                            {
                                root.val = (root.val * 10) + list[i].val;
                                AppendToOutput("number.val = " + root.val);
                            }
                        }
                        break;
                    case 1:
                        Console.WriteLine("________________________________________________________");
                        string state = "exp";
                        NonTerminal ro = ParseCase1(state, chars, 0, chars.Length - 1);
                        NonTerminal ro1 = threeCode(state, chars, 0, chars.Length - 1);
                        if (ro.val != int.MinValue)
                            AppendToOutput("exp.val = " + ro.val);
                        else
                            AppendToOutput("ERROR");
                        break;
                    case 2:
                        Console.WriteLine("________________________________________________________");
                        string state2 = "decl";
                        ParseCase2(state2, new string(chars), null);
                        break;
                    case 3:
                        Console.WriteLine("________________________________________________________");
                        string state3 = "based-num";
                        List<char> chars_List = new List<char>();
                        foreach (char ch in chars)
                        {
                            if (ch != ' ')
                            {
                                chars_List.Add(ch);
                            }
                        }
                        ParseCase3(state3, chars_List, new NonTerminal(0));
                        break;
                    default:
                        MessageBox.Show("No Grammar Selected", "ERROR",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                }
            }
            else
            {
                MessageBox.Show("Missing Input", "ERROR",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public NonTerminal ParseCase3(string state, List<char> chars, NonTerminal parent)
        {/* based-num -> num basechar\n" +
                        "2) basechar -> o\n" +
                        "3) basechar -> d\n" +
                        "4) num -> num digit\n" +
                        "5) num -> digit\n" +
            
          "1) based-num.val = num.val\n" +
                        "num.basee = basechar.basee" +
                        "2) basechar.basee = 8\n" +
                        "3) basechar.basee = 10\n" +
                        "4) if(digit.val == null || num2.val == null)\n" +
                        "num1.val = null\n" +
                        "else\n" +
                        "num1.val = (num2.val*num1.basee)+digit.val\n" +
                        "num2.basee = num1.basee\n" +
                        "digit.basee = num1.basee\n" +
                        "5) num.val = digit.val\n" +
                        "digit.basee = num.basee\n" +
                        "6) digit.val = 0\n" +
                        "7) digit.val = 1\n" +
                        "8) digit.val = 2\n" +
                        "9) digit.val = 3\n" +
                        "10) digit.val = 4\n" +
                        "11) digit.val = 5\n" +
                        "12) digit.val = 6\n" +
                        "13) digit.val = 7\n" +
                        "14) if(digit.basee == 8)\n" +
                        "digit.val = null\n" +
                        "else\n" +
                        "digit.val = 8\n" +
                        "15) if(digit.basee == 8)\n" +
                        "digit.val = null\n" +
                        "else\n" +
                        "digit.val = 9;

          */
            NonTerminal root = new NonTerminal(0);
            if (state == "based-num")
            {
                /*
                 * numbers go on the left
                 * last digit go to the right
                 * call on each
                 * 
                 
                 */
                List<char> right_in = new List<char>();
                char last = chars[chars.Count - 1];
                right_in.Add(last);
                chars.Remove(last);

                NonTerminal basechar = ParseCase3("basechar", right_in, parent);
                NonTerminal num = ParseCase3("num", chars, basechar);
                AppendToOutput("num.base = " + num.basee);
                root.val = num.val;
                AppendToOutput("based-num.val = " + root.val);

                   
               


            }
            else if (state == "basechar")
            {
                if (chars[0] == 'o')
                {
                    root.basee = 8;
                    AppendToOutput("base-char.base = 8");
                }
                else if (chars[0] == 'd')
                {
                    root.basee = 10;
                    AppendToOutput("base-char.base = 10");
                }
                else
                {
                    AppendToOutput("INPUT ERROR");
                }
            }
            else if (state == "num")
            {
                root.basee = parent.basee;
                if (chars.Count > 1)
                {
                    List<char> right_in = new List<char>();
                    char last = chars[chars.Count - 1];
                    right_in.Add(last);
                    chars.Remove(last);


                    NonTerminal num = ParseCase3("num", chars, parent);
                    AppendToOutput("num.base = " + num.basee);
                    NonTerminal digit = ParseCase3("digit", right_in, parent);
                    AppendToOutput("digit.base = " + digit.basee);

                    if (digit.val == int.MinValue || num.val == int.MinValue)
                    {
                        root.val = int.MinValue;
                        AppendToOutput("INPUT ERROR");
                    }
                    else
                    {
                        root.val = (num.val * num.basee) + digit.val;
                        AppendToOutput("num.val = " + root.val);
                    }
                }
                else
                {
                    NonTerminal digit = ParseCase3("digit", chars, parent);
                    root.val = digit.val;
                    AppendToOutput("digit.base = " + digit.basee);
                    AppendToOutput("num.val = " + root.val);
                }
            }
            else if (state == "digit")
            {
                root.basee = parent.basee;
                try
                {
                    string str = "" + chars[0];
                    int value = int.Parse(str);
                    if (value >= 0 && value <= 7)
                    {
                        root.val = value;
                        AppendToOutput("digit.inval = " + root.val);

                    }
                    else if (value >= 7 && value <= 9)
                    {
                        if (root.basee == 10)
                        {
                            root.val = value;
                            AppendToOutput("digit.inval = " + root.val);
                        }
                        else
                        {
                            AppendToOutput("INPUT ERROR");
                        }
                    }
                    else
                    {
                        AppendToOutput("INPUT ERROR");
                    }
                }
                catch (Exception)
                {
                    AppendToOutput("INPUT ERROR");
                }
            }
            return root;
        }

        public NonTerminal ParseCase2(string state, string input, string inherit)
        {
            NonTerminal root = new NonTerminal(0);
            if (state == "decl")
            {
                int breaker = -1;
                if (input.Length <= 4)
                {
                    MessageBox.Show("Incorrect Input", "ERROR",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return root;
                }
                else if (input.Substring(0, 4) == "int ")
                {
                    breaker = 4;
                }
                else if (input.Substring(0, 6) == "float ")
                         
                {
                    breaker = 6;
                }
                else
                {
                    MessageBox.Show("Incorrect Input", "ERROR",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return root;
                }
                NonTerminal type = ParseCase2("type", input.Substring(0, breaker - 1), null);

                NonTerminal vlist = ParseCase2("vlist", input.Substring(breaker), type.dtype);

            }
            else if (state == "type")
            {
                if (input[0] == 'i')
                {
                    root.dtype = "int";
                }
                else if (input[0] == 'f')
                {
                    root.dtype = "float";
                }
                AppendToOutput("type.dtype = " + root.dtype);
            }
            else if (state == "vlist")
            {
                root.dtype = inherit;
                AppendToOutput("var-list.dtype = " + root.dtype);
                bool found = false;
                string lhs = "";
                string rhs = "";
                for (int i = 0; i < input.Length; i++)
                {
                    if (input[i] == ',')
                    {
                        lhs = (input.Substring(0, i)).Trim();
                        rhs = (input.Substring(i + 1)).Trim();
                        found = true;
                        break;
                    }

                }
                if (found)
                {
                    NonTerminal id = ParseCase2("id", lhs, inherit);
                    NonTerminal vlist = ParseCase2("vlist", rhs, inherit);
                }
                else
                {
                    NonTerminal id = ParseCase2("id", input, inherit);
                }

            }
            else if (state == "id")
            {
                Regex idreg = new Regex("^[a-zA-Z_$][a-zA-Z_$0-9]*$");
                if (idreg.IsMatch(input) && (input != "int" || input != "float"))
                {
                    root.dtype = inherit;
                    AppendToOutput("id.dtype = " + root.dtype);
                }
                else
                {
                    AppendToOutput("PARSING ERROR");
                    return root;
                }

            }
            return root;
        }


        public NonTerminal ParseCase1(string state, char[] chars, int start, int end)
        {
            NonTerminal root = new NonTerminal(0);
            if (state == "exp")
            {
                bool found = false;
                int parenthesisChecker = 0;
                for (int i = end; i >= start; i--)
                {
                    if (chars[i] == '(')
                    {
                        parenthesisChecker--;
                    }
                    else if (chars[i] == ')')
                    {
                        parenthesisChecker++;
                    }
                    if ((chars[i] == '+' || chars[i] == '-') && (parenthesisChecker == 0))
                    {

                        found = true;
                        NonTerminal left = ParseCase1("exp", chars, start, i - 1);
                        //Console.WriteLine("exp.val = " + left.val);
                        AppendToOutput("exp.val = " + left.val);
                        NonTerminal right = ParseCase1("term", chars, i + 1, end);
                        //Console.WriteLine("term.val = " + right.val);
                        AppendToOutput("term.val = " + right.val);
                        if (chars[i] == '+')
                        {
                            root.val = (left.val + right.val);
                        }
                        else
                        {
                            root.val = (left.val - right.val);
                        }
                        break;
                    }

                }
                if (!found)
                {
                    NonTerminal term = ParseCase1("term", chars, start, end);
                    AppendToOutput("term.val = " + term.val);
                    root.val = term.val;
                }
            }
            else if (state == "term")
            {
                bool found = false;
                int started = 0;
                for (int i = end; i >= start; i--)
                {
                    if (chars[i] == '(')
                    {
                        started--;
                    }
                    else if (chars[i] == ')')
                    {
                        started++;
                    }
                    if ((chars[i] == '*') && (started == 0))
                    {
                        found = true;
                        NonTerminal left = ParseCase1("term", chars, start, i - 1);
                        AppendToOutput("term.val = " + left.val);
                        NonTerminal right = ParseCase1("factor", chars, i + 1, end);
                        AppendToOutput("factor.val = " + right.val);

                        root.val = (left.val * right.val);
                        break;
                    }

                }
                if (!found)
                {
                    NonTerminal factor = ParseCase1("factor", chars, start, end);
                    AppendToOutput("factor.val = " + factor.val);
                    root.val = factor.val;
                }
            }
            else if (state == "factor")
            {
                Regex num_reg = new Regex("^[0-9]+$");
                int stop = (end + 1) - start;
                try
                {
                    String str = new string(chars).Substring(start, stop);
                    if (num_reg.IsMatch(str))
                    {
                        NonTerminal number = ParseCase1("number", chars, start, end);
                        AppendToOutput("number.inval = " + number.val);
                        root.val = number.val;
                    }
                    else
                    {
                        NonTerminal exp = ParseCase1("exp", chars, start + 1, end - 1);
                        AppendToOutput("exp.val = " + exp.val);
                        root.val = exp.val;
                    }
                }
                catch (Exception e)
                {
                    //AppendToOutput(e.ToString);
                    MessageBox.Show("Incorrect Input", "ERROR",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return root;
                }

                //String str = (chars.ToString()).Substring(start, end);

            }
            else if (state == "number")
            {
                string str = new string(chars);
                int stop = (end + 1) - start;
                int val = int.Parse(str.Substring(start, stop));
                root.val = val;
            }
            return root;
        }

        public NonTerminal threeCode(string state, char[] chars, int start, int end)
        {

            NonTerminal root = new NonTerminal(0);
            if (state == "exp")
            {
                bool found = false;
                int parenthesisChecker = 0;
                for (int i = end; i >= start; i--)
                {
                    if (chars[i] == '(')
                    {
                        parenthesisChecker--;
                    }
                    else if (chars[i] == ')')
                    {
                        parenthesisChecker++;
                    }
                    if ((chars[i] == '+' || chars[i] == '-') && (parenthesisChecker == 0))
                    {

                        found = true;
                        NonTerminal left = threeCode("exp", chars, start, i - 1);
                        //Console.WriteLine("exp.val = " + left.val);
                        NonTerminal right = threeCode("term", chars, i + 1, end);
                        //Console.WriteLine("term.val = " + right.val);
                        if (chars[i] == '+')
                        {
                            myCount++;
                            root.val = (left.val + right.val);
                            if (left.var != null && right.var == null)
                            {
                                richTextBox3.AppendText("t" + myCount + " = " + left.var + " + " + right.val + "\n");
                                root.var = "t" + myCount;
                            }
                            else if (left.var == null && right.var != null)
                            {
                                richTextBox3.AppendText("t" + myCount + " = " + left.val + " + " + right.var + "\n");
                                root.var = "t" + myCount;
                            }
                            else if (left.var == null && right.var == null)
                            {
                                richTextBox3.AppendText("t" + myCount + " = " + left.val + " + " + right.val + "\n");
                                root.var = "t" + myCount;
                            }
                            else
                            {
                                richTextBox3.AppendText("t" + myCount + " = " + left.var + " + " + right.var + "\n");
                                root.var2 = "t" + myCount;
                            }
                        }
                        else
                        {
                            myCount++;
                            root.val = (left.val - right.val);

                            if (left.var != null && right.var == null)
                            {
                                richTextBox3.AppendText("t" + myCount + " = " + left.var + " - " + right.val + "\n");
                                root.var = "t" + myCount;
                            }
                            else if (left.var == null && right.var != null)
                            {
                                richTextBox3.AppendText("t" + myCount + " = " + left.val + " - " + right.var + "\n");
                                root.var = "t" + myCount;
                            }
                            else if (left.var == null && right.var == null)
                            {
                                richTextBox3.AppendText("t" + myCount + " = " + left.val + " - " + right.val + "\n");
                                root.var = "t" + myCount;
                            }
                            else
                            {
                                richTextBox3.AppendText("t" + myCount + " = " + left.var + " - " + right.var + "\n");
                            }


                        }
                        break;
                    }

                }
                if (!found)
                {
                    NonTerminal term = threeCode("term", chars, start, end);
                    AppendToOutput("term.val = " + term.val);
                    root.val = term.val;
                    root.var = term.var;
                }
            }
            else if (state == "term")
            {
                bool found = false;
                int started = 0;
                for (int i = end; i >= start; i--)
                {
                    if (chars[i] == '(')
                    {
                        started--;
                    }
                    else if (chars[i] == ')')
                    {
                        started++;
                    }
                    if ((chars[i] == '*') && (started == 0))
                    {
                        found = true;
                        NonTerminal left = threeCode("term", chars, start, i - 1);
                        NonTerminal right = threeCode("factor", chars, i + 1, end);
                        myCount++;
                        root.val = (left.val * right.val);

                        if (left.var != null && right.var == null)
                        {
                            richTextBox3.AppendText("t" + myCount + " = " + left.var + " * " + right.val + "\n");
                            root.var = "t" + myCount;
                        }
                        else if (left.var == null && right.var != null)
                        {
                            richTextBox3.AppendText("t" + myCount + " = " + left.val + " * " + right.var + "\n");
                            root.var = "t" + myCount;
                        }
                        else if (left.var == null && right.var == null)
                        {
                            richTextBox3.AppendText("t" + myCount + " = " + left.val + " * " + right.val + "\n");
                            root.var = "t" + myCount;
                        }
                        else
                        {
                            richTextBox3.AppendText("t" + myCount + " = " + left.var + " * " + right.var + "\n");
                        }


                        break;
                    }

                }
                if (!found)
                {
                    NonTerminal factor = threeCode("factor", chars, start, end);
                    AppendToOutput("factor.val = " + factor.val);
                    root.val = factor.val;
                    root.var = factor.var;
                }
            }
            else if (state == "factor")
            {
                Regex num_reg = new Regex("^[0-9]+$");
                int stop = (end + 1) - start;
                try
                {
                    String str = new string(chars).Substring(start, stop);
                    if (num_reg.IsMatch(str))
                    {
                        NonTerminal number = threeCode("number", chars, start, end);
                        AppendToOutput("number.inval = " + number.val);
                        root.val = number.val;

                    }
                    else
                    {
                        NonTerminal exp = threeCode("exp", chars, start + 1, end - 1);
                        AppendToOutput("exp.val = " + exp.val);
                        root.val = exp.val;
                        root.var = exp.var;
                    }
                }
                catch (Exception e)
                {
                    //AppendToOutput(e.ToString);
                    MessageBox.Show("Incorrect Input", "ERROR",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return root;
                }

                //String str = (chars.ToString()).Substring(start, end);

            }
            else if (state == "number")
            {
                string str = new string(chars);
                int stop = (end + 1) - start;
                int val = int.Parse(str.Substring(start, stop));
                root.val = val;
            }
            return root;
        }

        private void AppendToOutput(string text)
        {
            richTextBoxOutput.AppendText(text + Environment.NewLine);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Ensure an item is selected
            if (comboBox2.SelectedIndex == -1) return;

            // Get the selected item as a string
            string selectedItem = comboBox2.SelectedItem.ToString();

            // Switch case based on the selected item
            switch (selectedItem)
            {
                case "Code Movement":
                    ApplyCodeMovement();
                    break;

                case "Loop Unrolling":
                    // Code for Loop Unrolling
                    ApplyLoopUnrolling();
                    break;

                case "Constant Folding":
                    // Code for Dead Code Elimination

                    ApplyConstantFolding();
                    break;

                case "Code Hoisting":
                    // Code for Code Hoisting
                    MessageBox.Show("Code Hoisting selected");
                    break;

                case "Use of Machine Idioms":
                    // Code for Use of Machine Idioms
                    ApplyMachineIdioms();
                    break;

                default:
                    MessageBox.Show("Unknown selection");
                    break;
            }
        }

        private void ApplyCodeMovement()
        {
            string sourceCode = textBox3.Text;

            //string pattern = @"(\s*x\s*=\s*y\s*\+\s*z\s*;)(?!\s*.*\bj\b)\s*for\s*\(\s*int\s*j\s*=\s*0\s*;\s*j\s*<=\s*n\s*;\s*j\+\+\s*\)\s*\{\s*([^}]*)\s*\}";
            //string pattern = @"(x\s*=\s*y\s*\+\s*z\s*;).*for\s*\(\s*int\s*j";
            string pattern = @"x\s*=\s*y\s*\+\s*z\s*;";
            //Rearranging the code
            string optimizedCode = Regex.Replace(sourceCode, pattern, match =>
            {
                // Extract the moveable line and the rest of the loop body
                string moveableLine = match.Groups[0].Value;
                string loopBody = match.Groups[1].Value;

                // Construct the optimized code
                return $"{moveableLine}\n\nfor (int j = 0; j <= n; j++)\n{{\n{loopBody}\n";
            });

            // Set the optimized code to textBox2
            textBox2.Text = optimizedCode.Substring(31);
        }
        private void ApplyMachineIdioms()
        {
            string sourceCode = textBox3.Text;

            string patternIncrement = @"\b(\w+)\s*=\s*\1\s*\+\s*1\b";
            string patternDecrement = @"\b(\w+)\s*=\s*\1\s*-\s*1\b";

            string optimizedCode = Regex.Replace(sourceCode, patternIncrement, "$1++");

            optimizedCode = Regex.Replace(optimizedCode, patternDecrement, "$1--");

            // Set the optimized code to textBox2
            textBox2.Text = optimizedCode;
        }
        private void AppyLoopUnrolling()
        {

        }
        private void ApplyConstantFolding()
        {
            string[] strings = textBox3.Text.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);

            int result;
            for (int i = 0; i < strings.Length; i++)
            {
                if (strings[i] == "+")
                {
                    int num1, num2;
                    try
                    {
                        num1 = int.Parse(strings[i + 1]);
                        num2 = int.Parse(strings[i - 1]);
                    }
                    catch
                    {
                        continue;
                    }
                    result = num1 + num2;
                    strings[i] = (result.ToString());
                    strings[i - 1] = null;
                    strings[i + 1] = null;
                }
                else if (strings[i] == "-")
                {
                    int num1, num2;
                    try
                    {
                        num1 = int.Parse(strings[i + 1]);
                        num2 = int.Parse(strings[i - 1]);
                    }
                    catch
                    {
                        continue;
                    }
                    result = num1 - num2;
                    strings[i] = (result.ToString());
                    strings[i - 1] = null;
                    strings[i + 1] = null;
                }
                else if (strings[i] == "*")
                {
                    int num1, num2;
                    try
                    {
                        num1 = int.Parse(strings[i + 1]);
                        num2 = int.Parse(strings[i - 1]);
                    }
                    catch
                    {
                        continue;
                    }
                    result = num1 * num2;
                    strings[i] = (result.ToString());
                    strings[i - 1] = null;
                    strings[i + 1] = null;
                }
                else if (strings[i] == "/")
                {
                    int num1, num2;
                    try
                    {
                        num1 = int.Parse(strings[i + 1]);
                        num2 = int.Parse(strings[i - 1]);
                    }
                    catch
                    {
                        continue;
                    }
                    result = num2 / num1;
                    strings[i] = (result.ToString());
                    strings[i - 1] = null;
                    strings[i + 1] = null;
                }
            }
            for (int j = 0; j < strings.Length; j++)
            {
                textBox2.AppendText(strings[j] + " ");
            }
        }

        private void ApplyLoopUnrolling()
        {
            string sourceCode = textBox3.Text;

            // Regex pattern to match simple for-loops with iteration less than 3
            string pattern = @"for\s*\(\s*int\s+(\w+)\s*=\s*0\s*;\s*\1\s*<\s*(\d+)\s*;\s*\1\+\+\s*\)\s*\{\s*([^}]*)\s*\}";

            string unrolledCode = Regex.Replace(sourceCode, pattern, match =>
            {
                // Extracting the loop variable, upper limit, and loop body
                string loopVar = match.Groups[1].Value;
                int upperLimit = int.Parse(match.Groups[2].Value);
                string loopBody = match.Groups[3].Value;

                // If upper limit is less than 3, unroll the loop
                if (upperLimit < 3)
                {
                    StringBuilder unrolledLoop = new StringBuilder();
                    for (int i = 0; i < upperLimit; i++)
                    {
                        // Replace loop variable with current iteration value and add to unrolled loop
                        string iterationBody = Regex.Replace(loopBody, @"\b" + loopVar + @"\b", i.ToString());
                        unrolledLoop.AppendLine(iterationBody);
                    }
                    return unrolledLoop.ToString();
                }
                else
                {
                    // If upper limit is 3 or more, return the original loop
                    return match.Value;
                }
            });

            // Set the unrolled code to textBox2
            textBox2.Text = unrolledCode;
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            productionRules.Clear();
            firstSets.Clear();
            followSets.Clear();

            bool flag = true;

            string inputText = "";
            try
            {
                string filePath = "D:\\Study Material\\7th Semester\\Compiler Construction\\Compiler Construction\\CC Lab Terminal\\myGrammar.txt";

                using (StreamReader reader = new StreamReader(filePath))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        inputText += line;
                    }
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine("An error occurred while reading the file: " + ex.Message);
            }

            var productionRulesText = inputText.Split('.');
            foreach (var productionRuleText in productionRulesText)
            {
                var productionRuleParts = productionRuleText.Split('>');
                if (productionRuleParts.Length == 2)
                {
                    var nonTerminal = productionRuleParts[0].Trim();
                    var production = productionRuleParts[1].Trim();
                    if (!productionRules.ContainsKey(nonTerminal))
                    {
                        productionRules.Add(nonTerminal, production);
                    }
                    else
                    {
                        productionRules[nonTerminal] += "|" + production;
                    }
                }
            }

            if (flag)
            {
                foreach (var rule in productionRules)
                {
                    string nonTerminal = rule.Key;
                    CalculateFirstSet(nonTerminal);
                }

                string startSymbol = productionRules.Keys.Cast<string>().First();
                followSets[startSymbol] = new HashSet<string> { "$" };
                foreach (var nonTerminal in productionRules.Keys.Cast<string>())
                {
                    CalculateFollowSet(nonTerminal);
                }

                // Displaying First sets
                foreach (var entry in firstSets)
                {
                    var nonTerminal = entry.Key;
                    var firstSetText = string.Join(", ", entry.Value);
                    firstAndFollowBox.AppendText($"First({nonTerminal}) = {{{firstSetText}}}\n");
                }

                // Displaying Follow sets
                foreach (var entry in followSets)
                {
                    var nonTerminal = entry.Key;
                    var followSetText = string.Join(", ", entry.Value);
                    firstAndFollowBox.AppendText($"Follow({nonTerminal}) = {{{followSetText}}}\n");
                }
            }
            CreateParsingTable();
            SimulateLL1Parser();
        }

        private void CalculateFirstSet(string nonTerminal)
        {
            if (firstSets.ContainsKey(nonTerminal))
                return;

            var firstSet = new HashSet<string>();
            firstSets[nonTerminal] = firstSet;

            var productions = productionRules[nonTerminal].ToString().Split('|');
            foreach (var production in productions)
            {
                if (production.Trim() == "null")
                {
                    firstSet.Add("null");
                    continue;
                }

                var symbols = production.Split(' ');
                bool shouldContinue = true;

                foreach (var symbol in symbols)
                {
                    if (shouldContinue)
                    {
                        if (productionRules.ContainsKey(symbol))
                        {
                            CalculateFirstSet(symbol);
                            var symbolFirstSet = firstSets[symbol] as HashSet<string>;
                            firstSet.UnionWith(symbolFirstSet.Where(x => x != "null"));
                        }
                        else
                        {
                            firstSet.Add(symbol);
                        }

                        if (!firstSets.ContainsKey(symbol) || !(firstSets[symbol] as HashSet<string>).Contains("null"))
                        {
                            shouldContinue = false;
                        }
                    }
                }

                if (shouldContinue)
                {
                    firstSet.Add("null");
                }
            }
        }

        private void CalculateFollowSet(string nonTerminal)
        {
            // Ensure the followSets dictionary is initialized for the given non-terminal
            if (!followSets.ContainsKey(nonTerminal))
            {
                followSets[nonTerminal] = new HashSet<string>();
            }

            // If the non-terminal is the start symbol, add "$" to its FOLLOW set.
            if (nonTerminal == "S") // assuming "S" is the start symbol
            {
                followSets[nonTerminal].Add("$");
            }

            foreach (var rule in productionRules)
            {
                string lhs = rule.Key;
                string[] rhsProductions = rule.Value.Split('|');

                foreach (var production in rhsProductions)
                {
                    string[] symbols = production.Split(' ');

                    for (int i = 0; i < symbols.Length; i++)
                    {
                        if (symbols[i] == nonTerminal && i + 1 < symbols.Length)
                        {
                            bool canReachEpsilon = true;
                            int j = i + 1;

                            while (canReachEpsilon && j < symbols.Length)
                            {
                                if (firstSets.ContainsKey(symbols[j]))
                                {
                                    foreach (var item in firstSets[symbols[j]].Where(x => x != "null"))
                                    {
                                        followSets[nonTerminal].Add(item);
                                    }

                                    canReachEpsilon = firstSets[symbols[j]].Contains("null");
                                }
                                else
                                {
                                    followSets[nonTerminal].Add(symbols[j]);
                                    canReachEpsilon = false;
                                }

                                j++;
                            }

                            if (canReachEpsilon && lhs != nonTerminal)
                            {
                                CalculateFollowSet(lhs);
                                foreach (var item in followSets[lhs])
                                {
                                    followSets[nonTerminal].Add(item);
                                }
                            }
                        }
                    }
                }
            }
        }




        private void CreateParsingTable()
        {
            dataGridView3.Columns.Clear();
            dataGridView3.Rows.Clear();

            HashSet<string> allTerminals = new HashSet<string> { "$" };

            foreach (var pair in firstSets)
            {
                allTerminals.UnionWith(pair.Value);
            }

            allTerminals.Remove("null"); // "null" (epsilon) should not be a column header

            // Add terminals as columns
            foreach (string terminal in allTerminals)
            {
                if (!dataGridView3.Columns.Contains(terminal))
                {
                    dataGridView3.Columns.Add(terminal, terminal);
                }
            }

            // Add non-terminals as rows with headers
            foreach (string nonTerminal in productionRules.Keys)
            {
                int rowIndex = dataGridView3.Rows.Add();
                dataGridView3.Rows[rowIndex].HeaderCell.Value = nonTerminal;
            }

            foreach (var entry in productionRules)
            {
                string nonTerminal = entry.Key;
                int rowIndex = dataGridView3.Rows.Cast<DataGridViewRow>().ToList().FindIndex(r => r.HeaderCell?.Value?.ToString() == nonTerminal);

                if (rowIndex == -1) continue; // Skip if not found to avoid out of range

                foreach (string production in entry.Value.Split('|'))
                {
                    var firstOfProduction = GetFirstOfProduction(production);

                    foreach (string terminal in firstOfProduction)
                    {
                        if (terminal == "null" && followSets.ContainsKey(nonTerminal))
                        {
                            foreach (string followTerminal in followSets[nonTerminal])
                            {
                                if (dataGridView3.Columns.Contains(followTerminal))
                                {
                                    int colIndex = dataGridView3.Columns[followTerminal].Index;
                                    dataGridView3.Rows[rowIndex].Cells[colIndex].Value = production;
                                }
                            }
                        }
                        else if (dataGridView3.Columns.Contains(terminal))
                        {
                            int colIndex = dataGridView3.Columns[terminal].Index;
                            dataGridView3.Rows[rowIndex].Cells[colIndex].Value = production;
                        }
                    }
                }
            }
        }


        private HashSet<string> GetFirstOfProduction(string production)
        {
            HashSet<string> result = new HashSet<string>();
            var symbols = production.Split(' ');

            foreach (var symbol in symbols)
            {
                if (firstSets.ContainsKey(symbol))
                {
                    result.UnionWith(firstSets[symbol]);
                }
                else
                {
                    result.Add(symbol);
                    break;
                }

                if (!result.Contains("null"))
                {
                    break;
                }
                else
                {
                    result.Remove("null");
                }
            }
            return result;
        }
        private void SimulateLL1Parser()
        {
            InitializeDataGridView2();

            Stack<string> parsingStack = InitializeParsingStack();
            string inputTape = inputTapeTextBox.Text + "$";
            int tapeIndex = 0;

            while (parsingStack.Count > 0)
            {
                string topOfStack = parsingStack.Peek();
                if (inputTape[tapeIndex] == ' ')
                {
                    tapeIndex++;
                    continue;
                }
                string currentInputSymbol = inputTape[tapeIndex].ToString();

                if (currentInputSymbol == "$")
                {
                    break;
                }

                if (IsTerminal(topOfStack))
                {
                    ProcessTerminal(parsingStack, ref tapeIndex, currentInputSymbol, inputTape);
                }
                else if (HasProductionRule(topOfStack, currentInputSymbol))
                {
                    ProcessNonTerminal(parsingStack, topOfStack, currentInputSymbol, ref tapeIndex, inputTape);
                }
                else
                {
                    AddRowToDataGridView2(parsingStack, inputTape.Substring(tapeIndex), $"Error: Unexpected symbol '{currentInputSymbol}' at position {tapeIndex} while {topOfStack} at the top");
                    return; // Exit function on error
                }
            }

            dataGridView4.Rows.Add(new string[] { "$", "$", "Accept" });
        }

        private bool IsTerminal(string symbol)
        {

            return !productionRules.ContainsKey(symbol);
        }

        private bool HasProductionRule(string nonTerminal, string currentSymbol)
        {
            int rowIndex = dataGridView3.Rows.Cast<DataGridViewRow>().ToList().FindIndex(r => r.HeaderCell?.Value?.ToString() == nonTerminal);
            return dataGridView3.Columns.Contains(currentSymbol) && dataGridView3.Rows[rowIndex].Cells[currentSymbol].Value != null;
        }

        private void ProcessTerminal(Stack<string> stack, ref int tapeIndex, string currentInputSymbol, string inputTape)
        {

            if (stack.Peek() == currentInputSymbol)
            {
                stack.Pop();
                tapeIndex++;

                AddRowToDataGridView2(stack, inputTape.Substring(tapeIndex), "Match: " + currentInputSymbol);
            }
            else
            {
                AddRowToDataGridView2(stack, inputTape.Substring(tapeIndex), $"Error: Expected '{stack.Peek()}' but found '{currentInputSymbol}' at position {tapeIndex}");
            }
        }

        private void ProcessNonTerminal(Stack<string> stack, string nonTerminal, string currentInputSymbol, ref int tapeIndex, string inputTape)
        {
            int rowIndex = dataGridView3.Rows.Cast<DataGridViewRow>().ToList().FindIndex(r => r.HeaderCell?.Value?.ToString() == nonTerminal);
            int colIndex = dataGridView3.Columns[currentInputSymbol].Index;
            string production = dataGridView3.Rows[rowIndex].Cells[colIndex].Value?.ToString();

            stack.Pop();

            if (production != "null")
            {
                var symbols = production.Split(' ').Reverse();
                foreach (var symbol in symbols)
                {
                    stack.Push(symbol);
                }
            }

            AddRowToDataGridView2(stack, inputTape.Substring(tapeIndex), "Generate: " + production);
        }

        private void InitializeDataGridView2()
        {
            dataGridView4.Rows.Clear();
            dataGridView4.Columns.Clear();

            dataGridView4.Columns.Add("Stack", "Stack");
            dataGridView4.Columns.Add("InputTape", "Input Tape");
            dataGridView4.Columns.Add("Action", "Action");
        }

        private Stack<string> InitializeParsingStack()
        {
            Stack<string> stack = new Stack<string>();
            stack.Push("$");
            stack.Push("S"); // Starting symbol
            return stack;
        }

        private void AddRowToDataGridView2(Stack<string> stack, string inputTape, string action)
        {
            string stackContent = string.Join("", stack.Reverse()); // Convert stack to string
            dataGridView4.Rows.Add(new string[] { stackContent, inputTape, action });
        }

          private void label15_Click(object sender, EventArgs e)
          {

          }

          private void label6_Click(object sender, EventArgs e)
        {

        }

        private void stack_TextChanged(object sender, EventArgs e)
        {
            Console.WriteLine("UPDATING STACK...");
        }

        int sum, sub, mul, div, equal, greater, less, intCount, floatCount, stringCount, boolCount, forCount, ifCount = 0;
        int totalOperators, totalKeywords, totalIdentifiers, totalConstants = 0;

        // grammar definition
        Hashtable grammar = new Hashtable()
        {
            { "prog", "main () { Main-Body }" },
            { "Main-Body", "decl assign IF FOR" },
            { "decl", "type id var-list decl-assign decl | null" },
            { "decl-assign", "= exp ; | ;"},
            { "var-list", ", id var-list | null" },
            { "assign", "id = exp ; assign| null" },
            { "exp", "term exp1| num " },
            { "exp1", "addop term exp1 | null" },
            { "addop", "+ | -" },
            { "term", "factor term1"},
            { "term1","mulop factor term1 | null"},
            { "mulop", "* | /"},
            { "factor", "( exp ) | num | id"},
            { "type", "int | float | string | bool"},
            { "IF", "if ( cond ) stmt | null"},
            { "cond", "id comp exp"},
            { "comp", "< | >"},
            { "stmt", "print ;"},
            { "FOR", "for ( init ; cond ; inc ) { assign ; } | null"},
            { "init", "int id = num"},
            { "inc", "id ++"}
        };

        public Form1()
        {
            InitializeComponent();
            dataGridView1.ColumnCount = 3;
            dataGridView1.Columns[0].Name = "Line No.";
            dataGridView1.Columns[1].Name = "Operators";
            dataGridView1.Columns[2].Name = "Count";

            dataGridView2.ColumnCount = 6;
            dataGridView2.Columns[0].Name = "Line No.";
            dataGridView2.Columns[1].Name = "Identifier";
            dataGridView2.Columns[2].Name = "DataType / Keyword";
            dataGridView2.Columns[3].Name = "Value";
            dataGridView2.Columns[4].Name = "Operator";
            dataGridView2.Columns[5].Name = "Semantic";

            quad.ColumnCount = 5;
            quad.Columns[0].Name = "Address";
            quad.Columns[1].Name = "Operator";
            quad.Columns[2].Name = "OP 1";
            quad.Columns[3].Name = "OP 2";
            quad.Columns[4].Name = "Result";
            dataGridView1.Visible = false;

        }

        private void button3_Click(object sender, EventArgs e)

        {
            // ***********************LL1 parsing table start************************************ //
            var parsingTable = new Dictionary<string, Dictionary<string, string>>();
            parsingTable.Add("prog", new Dictionary<string, string>()
            {
                { "main", "main ( ) { Main-Body }" },
                { "(", "" },
                { ")", "" },
                { "{", "" },
                { "}", "" },
                { ";", "" },
                { ",", "" },
                { "id", "" },
                { "num", "" },
                { "=", "" },
                { "+", "" },
                { "-", "" },
                { "*", "" },
                { "/", "" },
                { "int", "" },
                { "float", "" },
                { "string", "" },
                { "bool", "" },
                { "if", "" },
                { "for", "" },
                { ">", "" },
                { "<", "" },
                { "print", "" },
                { "++", "" },
                { "$", "" }
            });

            parsingTable.Add("Main-Body", new Dictionary<string, string>()
            {
                { "main", "" },
                { "(", "" },
                { ")", "" },
                { "{", "" },
                { "}", "null" },
                { ";", "" },
                { ",", "" },
                { "id", "" },
                { "num", "" },
                { "=", "" },
                { "+", "" },
                { "-", "" },
                { "*", "" },
                { "/", "" },
                { "int", "decl assign IF FOR" },
                { "float", "decl assign IF FOR" },
                { "string", "decl assign IF FOR" },
                { "bool", "decl assign IF FOR" },
                { "if", "" },
                { "for", "" },
                { ">", "" },
                { "<", "" },
                { "print", "" },
                { "++", "" },
                { "$", "" }
            });

            parsingTable.Add("decl", new Dictionary<string, string>()
            {
                { "main", "" },
                { "(", "" },
                { ")", "" },
                { "{", "" },
                { "}", "null" },
                { ";", "null" },
                { ",", "" },
                { "id", "null" },
                { "num", "" },
                { "=", "" },
                { "+", "" },
                { "-", "" },
                { "*", "" },
                { "/", "" },
                { "int", "type id var-list decl-assign decl" },
                { "float", "type id var-list decl-assign decl" },
                { "string", "type id var-list decl-assign decl" },
                { "bool", "type id var-list decl-assign decl" },
                { "if", "" },
                { "for", "" },
                { ">", "" },
                { "<", "" },
                { "print", "" },
                { "++", "" },
                { "$", "" }
            });
            parsingTable.Add("decl-assign", new Dictionary<string, string>()
            {
                { "main", "" },
                { "(", "" },
                { ")", "" },
                { "{", "" },
                { "}", "null" },
                { ";", ";" },
                { ",", "" },
                { "id", "null" },
                { "num", "" },
                { "=", "= exp ;" },
                { "+", "" },
                { "-", "" },
                { "*", "" },
                { "/", "" },
                { "int", "null " },
                { "float", "null" },
                { "string", "null" },
                { "bool", "null" },
                { "if", "" },
                { "for", "" },
                { ">", "" },
                { "<", "" },
                { "print", "" },
                { "++", "" },
                { "$", "" }
            });
            parsingTable.Add("assign", new Dictionary<string, string>()
            {
                { "main", "" },
                { "(", "" },
                { ")", "" },
                { "{", "" },
                { "}", "null" },
                { ";", "" },
                { ",", "" },
                { "id", "id = exp ; assign" },
                { "num", "" },
                { "=", "" },
                { "+", "" },
                { "-", "" },
                { "*", "" },
                { "/", "" },
                { "int", "" },
                { "float", "" },
                { "string", "" },
                { "bool", "" },
                { "if", "null" },
                { "for", "" },
                { ">", "" },
                { "<", "" },
                { "print", "" },
                { "++", "" },
                { "$", "" }
            });

            parsingTable.Add("IF", new Dictionary<string, string>()
            {
                { "main", "" },
                { "(", "" },
                { ")", "" },
                { "{", "" },
                { "}", "null" },
                { ";", "" },
                { ",", "" },
                { "id", "" },
                { "num", "" },
                { "=", "" },
                { "+", "" },
                { "-", "" },
                { "*", "" },
                { "/", "" },
                { "int", "" },
                { "float", "" },
                { "string", "" },
                { "bool", "" },
                { "if", "if ( cond ) stmt" },
                { "for", "null" },
                { ">", "" },
                { "<", "" },
                { "print", "" },
                { "++", "" },
            });

            parsingTable.Add("FOR", new Dictionary<string, string>()
            {
                { "main", "" },
                { "(", "" },
                { ")", "" },
                { "{", "" },
                { "}", "null" },
                { ";", "" },
                { ",", "" },
                { "id", "" },
                { "num", "" },
                { "=", "" },
                { "+", "" },
                { "-", "" },
                { "*", "" },
                { "/", "" },
                { "int", "" },
                { "float", "" },
                { "string", "" },
                { "bool", "" },
                { "if", "" },
                { "for", "for ( init ; cond ; inc ) { assign }" },
                { ">", "" },
                { "<", "" },
                { "print", "" },
                { "++", "" },
            });

            parsingTable.Add("type", new Dictionary<string, string>()
            {
                { "main", "" },
                { "(", "" },
                { ")", "" },
                { "{", "" },
                { "}", "" },
                { ";", "" },
                { ",", "" },
                { "id", "" },
                { "num", "" },
                { "=", "" },
                { "+", "" },
                { "-", "" },
                { "*", "" },
                { "/", "" },
                { "int", "int" },
                { "float", "float" },
                { "string", "string" },
                { "bool", "bool" },
                { "if", "" },
                { "for", "" },
                { ">", "" },
                { "<", "" },
                { "print", "" },
                { "++", "" },
            });

            parsingTable.Add("var-list", new Dictionary<string, string>()
            {
                { "main", "" },
                { "(", "" },
                { ")", "" },
                { "{", "" },
                { "}", "" },
                { ";", "null" },
                { ",", ", id var-list" },
                { "id", "" },
                { "num", "" },
                { "=", "null" },
                { "+", "" },
                { "-", "" },
                { "*", "" },
                { "/", "" },
                { "int", "" },
                { "float", "" },
                { "string", "" },
                { "bool", "" },
                { "if", "" },
                { "for", "" },
                { ">", "" },
                { "<", "" },
                { "print", "" },
                { "++", "" },
            });

            parsingTable.Add("exp", new Dictionary<string, string>()
            {
                { "main", "" },
                { "(", "term exp1" },
                { ")", "" },
                { "{", "" },
                { "}", "" },
                { ";", "" },
                { ",", "" },
                { "id", "term exp1" },
                { "num", "term exp1" },
                { "=", "" },
                { "+", "" },
                { "-", "" },
                { "*", "" },
                { "/", "" },
                { "int", "" },
                { "float", "" },
                { "string", "" },
                { "bool", "" },
                { "if", "" },
                { "for", "" },
                { ">", "" },
                { "<", "" },
                { "print", "" },
                { "++", "" }
            });
            parsingTable.Add("exp1", new Dictionary<string, string>()
            {
                { "main", "" },
                { "(", "" },
                { ")", "null" },
                { "{", "" },
                { "}", "" },
                { ";", "null" },
                { ",", "" },
                { "id", "" },
                { "num", "null" },
                { "=", "" },
                { "+", "addop term exp1" },
                { "-", "addop term exp1" },
                { "*", "" },
                { "/", "" },
                { "int", "" },
                { "float", "" },
                { "string", "" },
                { "bool", "" },
                { "if", "" },
                { "for", "" },
                { ">", "" },
                { "<", "" },
                { "print", "" },
                { "++", "" }
            });
            parsingTable.Add("addop", new Dictionary<string, string>()
            {
                { "main", "" },
                { "(", "" },
                { ")", "" },
                { "{", "" },
                { "}", "" },
                { ";", "" },
                { ",", "" },
                { "id", "" },
                { "num", "" },
                { "=", "" },
                { "+", "+" },
                { "-", "-" },
                { "*", "" },
                { "/", "" },
                { "int", "" },
                { "float", "" },
                { "string", "" },
                { "bool", "" },
                { "if", "" },
                { "for", "" },
                { ">", "" },
                { "<", "" },
                { "print", "" },
                { "++", "" }
            });
            parsingTable.Add("term", new Dictionary<string, string>()
            {
                { "main", "" },
                { "(", "factor term1" },
                { ")", "" },
                { "{", "" },
                { "}", "" },
                { ";", "" },
                { ",", "" },
                { "id", "factor term1" },
                { "num", "factor term1" },
                { "=", "" },
                { "+", "" },
                { "-", "" },
                { "*", "" },
                { "/", "" },
                { "int", "" },
                { "float", "" },
                { "string", "" },
                { "bool", "" },
                { "if", "" },
                { "for", "" },
                { ">", "" },
                { "<", "" },
                { "print", "" },
                { "++", "" }
            });
            parsingTable.Add("term1", new Dictionary<string, string>()
            {
                { "main", "" },
                { "(", "" },
                { ")", "null" },
                { "{", "" },
                { "}", "" },
                { ";", "null" },
                { ",", "" },
                { "id", "null" },
                { "num", "null" },
                { "=", "" },
                { "+", "null" },
                { "-", "null" },
                { "*", "mulop factor term1" },
                { "/", "mulop factor term1" },
                { "int", "" },
                { "float", "" },
                { "string", "" },
                { "bool", "" },
                { "if", "" },
                { "for", "" },
                { ">", "" },
                { "<", "" },
                { "print", "" },
                { "++", "" }
            });
            parsingTable.Add("mulop", new Dictionary<string, string>()
            {
                { "main", "" },
                { "(", "" },
                { ")", "" },
                { "{", "" },
                { "}", "" },
                { ";", "" },
                { ",", "" },
                { "id", "" },
                { "num", "" },
                { "=", "" },
                { "+", "" },
                { "-", "" },
                { "*", "*" },
                { "/", "/" },
                { "int", "" },
                { "float", "" },
                { "string", "" },
                { "bool", "" },
                { "if", "" },
                { "for", "" },
                { ">", "" },
                { "<", "" },
                { "print", "" },
                { "++", "" }
            });
            parsingTable.Add("factor", new Dictionary<string, string>()
            {
                { "main", "" },
                { "(", "( exp )" },
                { ")", "" },
                { "{", "" },
                { "}", "" },
                { ";", "" },
                { ",", "" },
                { "id", "id" },
                { "num", "num" },
                { "=", "" },
                { "+", "" },
                { "-", "-" },
                { "*", "" },
                { "/", "" },
                { "int", "" },
                { "float", "" },
                { "string", "" },
                { "bool", "" },
                { "if", "" },
                { "for", "" },
                { ">", "" },
                { "<", "" },
                { "print", "" },
                { "++", "" }
            });

            parsingTable.Add("cond", new Dictionary<string, string>()
            {
                { "main", "" },
                { "(", "" },
                { ")", "" },
                { "{", "" },
                { "}", "" },
                { ";", "" },
                { ",", "" },
                { "id", "id comp exp" },
                { "num", "" },
                { "=", "" },
                { "+", "" },
                { "-", "-" },
                { "*", "" },
                { "/", "" },
                { "int", "" },
                { "float", "" },
                { "string", "" },
                { "bool", "" },
                { "if", "" },
                { "for", "" },
                { ">", "" },
                { "<", "" },
                { "print", "" },
                { "++", "" }
            });
            parsingTable.Add("comp", new Dictionary<string, string>()
            {
                { "main", "" },
                { "(", "" },
                { ")", "" },
                { "{", "" },
                { "}", "" },
                { ";", "" },
                { ",", "" },
                { "id", "" },
                { "num", "" },
                { "=", "" },
                { "+", "" },
                { "-", "-" },
                { "*", "" },
                { "/", "" },
                { "int", "" },
                { "float", "" },
                { "string", "" },
                { "bool", "" },
                { "if", "" },
                { "for", "" },
                { ">", ">" },
                { "<", "<" },
                { "print", "" },
                { "++", "" }
            });
            parsingTable.Add("stmt", new Dictionary<string, string>()
            {
                { "main", "" },
                { "(", "" },
                { ")", "" },
                { "{", "" },
                { "}", "" },
                { ";", "" },
                { ",", "" },
                { "id", "" },
                { "num", "" },
                { "=", "" },
                { "+", "" },
                { "-", "-" },
                { "*", "" },
                { "/", "" },
                { "int", "" },
                { "float", "" },
                { "string", "" },
                { "bool", "" },
                { "if", "" },
                { "for", "" },
                { ">", "" },
                { "<", "" },
                { "print", "print ;" },
                { "++", "" }
            });
            parsingTable.Add("init", new Dictionary<string, string>()
            {
                { "main", "" },
                { "(", "" },
                { ")", "" },
                { "{", "" },
                { "}", "" },
                { ";", "" },
                { ",", "" },
                { "id", "" },
                { "num", "" },
                { "=", "" },
                { "+", "" },
                { "-", "-" },
                { "*", "" },
                { "/", "" },
                { "int", "int id = num" },
                { "float", "" },
                { "string", "" },
                { "bool", "" },
                { "if", "" },
                { "for", "" },
                { ">", "" },
                { "<", "" },
                { "print", "" },
                { "++", "" }
            });
            parsingTable.Add("inc", new Dictionary<string, string>()
            {
                { "main", "" },
                { "(", "" },
                { ")", "" },
                { "{", "" },
                { "}", "" },
                { ";", "" },
                { ",", "" },
                { "id", "id ++" },
                { "num", "" },
                { "=", "" },
                { "+", "" },
                { "-", "-" },
                { "*", "" },
                { "/", "" },
                { "int", "" },
                { "float", "" },
                { "string", "" },
                { "bool", "" },
                { "if", "" },
                { "for", "" },
                { ">", "" },
                { "<", "" },
                { "print", "" },
                { "++", "" }
            });
            // ***********************LL1 parsing table end************************************ //

            Regex operatorRegex = new Regex(@"^[+|\-|*|/|[&&]|[||]|\~|>|<|[>=]|[<=]|[==]]$");
            string[] keywords = new string[] { "int", "double", "float", "string", "bool", "char", "if", "for", "main", "print", "id", "num" };
            Regex constantRegex = new Regex(@"^[0-9][0-9]*(([.][0-9])?)$");
            Regex floatRegex = new Regex(@"^(([0-9][0-9]*[.][0-9][0-9]*[;]*)?)$");
            Regex intRegex = new Regex(@"^[0-9][0-9]*[;]*$");
            Regex alphaNumericRegex = new Regex(@"^[A-Za-z][A-Za-z]*[0-9]*$");
            Regex r = new Regex(@"""[^""\\]*(?:\\.[^""\\]*)*""");
            Regex identifierRegex = new Regex(@"^[A-Za-z]*[A-Za-z][++]*$");
            Regex strRegex = new Regex(@"[^\w\s]");
            //Regex boolRegex = new Regex(@"[true]|[false]");
            Regex tRegex = new Regex(@"^[t][0-9][0-9]*$");
            string line = "";
            char[] unwanted = { ';', '+' };

            ArrayList identifierToPrint = new ArrayList();

            System.IO.StreamReader file = new System.IO.StreamReader(@filepath);
            while ((line = file.ReadLine()) != null)
            {
                string var = "";
                String key = "";
                string constant = "";
                string operators = "";
                string comment = "";
                string word = "";
                string boolValues = "";

                String[] words = line.Split(' ');
                int flag = 0;
                int index = 0;
                //getting first index which contains " and deleting it
                for (int j = 0; j < words.Length; j++)
                {
                    if (words[j].Contains('"'))
                    {
                        flag = 1;
                        index = j;
                        word += words[j] + " ";
                        words = words.Where((val, idx) => idx != j).ToArray();
                        break;
                    }
                }

                //putting all indexes that comes before the ending " index
                if (flag == 1)
                {
                    for (int k = index; k < words.Length; k++)
                    {
                        if (words[k].Contains('"'))
                        {
                            word += words[k] + " ";
                            break;
                        }
                        else
                        {
                            word += words[k] + " ";
                        }
                    }

                    //deleting the indexes which contains the parts of string
                    for (int k = index; k < words.Length; k++)
                    {
                        if (words[k].Contains('"'))
                        {
                            words = words.Where((val, idx) => idx != k).ToArray();
                            words = words.Where((val, idx) => idx != index).ToArray();
                            break;
                        }
                        else
                        {
                            words = words.Where((val, idx) => idx != k).ToArray();
                        }
                    }
                    totalConstants++;
                }

                for (int i = 0; i < words.Length; i++)
                {
                    if (keywords.Contains(words[i]))
                    {
                        if (key.Equals(""))
                        {
                            key = words[i];

                        }
                        else
                        {
                            key += ", " + words[i];

                        }
                    }
                    else
                    {

                        Match idMatch = identifierRegex.Match(words[i]);
                        //  Match boolMatch = boolRegex.Match(words[i]);
                        Match constMatch = constantRegex.Match(words[i]);
                        Match intMatch = intRegex.Match(words[i]);
                        Match floatMatch = floatRegex.Match(words[i]);
                        Match operatorMatch = operatorRegex.Match(words[i]);
                        if (idMatch.Success && !words[i].Equals("true") && !words[i].Equals("false"))
                        {
                            if (line.StartsWith("for"))
                            {
                                if (var.Equals(""))
                                {
                                    if (!identifierToPrint.Contains(words[i].TrimEnd(unwanted)))
                                    {
                                        identifierToPrint.Add(words[i].TrimEnd(unwanted));
                                        totalIdentifiers++;
                                    }
                                    var = words[i].TrimEnd(unwanted);
                                }
                                else
                                {
                                    string[] temp = var.Split(',');
                                    if (!identifierToPrint.Contains(words[i].TrimEnd(unwanted)))
                                    {
                                        identifierToPrint.Add(words[i].TrimEnd(unwanted));
                                        totalIdentifiers++;
                                    }
                                    if (!words[i].TrimEnd(unwanted).Equals(temp[0]))
                                    {
                                        comment = "for statement must contain same identifiers";
                                        var += ", " + words[i].TrimEnd(unwanted);

                                    }
                                }
                            }
                            else
                            {
                                if (var.Equals(""))
                                {
                                    if (!identifierToPrint.Contains(words[i].TrimEnd(unwanted)))
                                    {
                                        identifierToPrint.Add(words[i].TrimEnd(unwanted));
                                        totalIdentifiers++;
                                    }
                                    var = words[i].TrimEnd(unwanted);

                                }
                                else
                                {
                                    if (!identifierToPrint.Contains(words[i].TrimEnd(unwanted)))
                                    {
                                        var += ", " + words[i].TrimEnd(unwanted);
                                        identifierToPrint.Add(words[i].TrimEnd(unwanted));
                                        totalIdentifiers++;
                                    }
                                    else
                                    {

                                        var += ", " + words[i].TrimEnd(unwanted);

                                    }
                                }
                            }
                        }

                        if (intMatch.Success || floatMatch.Success)
                        {
                            if (constant.Equals(""))
                            {
                                constant = words[i].TrimEnd(unwanted);
                                totalConstants++;
                            }
                            else
                            {
                                constant += "," + words[i].TrimEnd(unwanted);
                                totalConstants++;
                            }
                        }

                        if (words[i].Equals("true") || words[i].Equals("false"))
                        {
                            if (constant.Equals(""))
                            {
                                constant = words[i].TrimEnd(unwanted);
                                totalConstants++;
                            }
                            else
                            {
                                constant += "," + words[i].TrimEnd(unwanted);
                                totalConstants++;
                            }
                        }

                        if (operatorMatch.Success)
                        {
                            switch (words[i])
                            {
                                case "+":
                                    sumCount++;
                                    totalOperators++;
                                    sum++;
                                    break;
                                case "-":
                                    subCount++;
                                    totalOperators++;
                                    sub++;
                                    break;
                                case "*":
                                    mulCount++;
                                    totalOperators++;
                                    mul++;
                                    break;
                                case "/":
                                    divCount++;
                                    totalOperators++;
                                    div++;
                                    break;
                                case "=":
                                    equalCount++;
                                    totalOperators++;
                                    equal++;
                                    break;
                                case ">":
                                    greaterCount++;
                                    totalOperators++;
                                    greater++;
                                    break;
                                case "<":
                                    lessCount++;
                                    totalOperators++;
                                    less++;
                                    break;
                                default: break;
                            }
                        }
                    }
                }
                lineNo++;

                if (sumCount > 0)
                {
                    if (operators.Equals(""))
                    {
                        operators = "+";
                    }
                    else
                    {
                        operators += ", +";
                    }
                    row = new string[] { (lineNo).ToString(), "+", sumCount.ToString() };
                    dataGridView1.Rows.Add(row);
                    sumCount = 0;
                }
                if (subCount > 0)
                {
                    if (operators.Equals(""))
                    {
                        operators = "-";
                    }
                    else
                    {
                        operators += ", -";
                    }
                    row = new string[] { (lineNo).ToString(), "-", subCount.ToString() };
                    dataGridView1.Rows.Add(row);
                    subCount = 0;
                }
                if (mulCount > 0)
                {
                    if (operators.Equals(""))
                    {
                        operators = "*";
                    }
                    else
                    {
                        operators += ", *";
                    }
                    row = new string[] { (lineNo).ToString(), "*", mulCount.ToString() };
                    dataGridView1.Rows.Add(row);
                    mulCount = 0;
                }
                if (divCount > 0)
                {
                    if (operators.Equals(""))
                    {
                        operators = "/";
                    }
                    else
                    {
                        operators += ", /";
                    }
                    row = new string[] { (lineNo).ToString(), "/", divCount.ToString() };
                    dataGridView1.Rows.Add(row);
                    divCount = 0;
                }

                if (equalCount > 0)
                {
                    if (operators.Equals(""))
                    {
                        operators = "=";
                    }
                    else
                    {
                        operators += ", =";
                    }
                    row = new string[] { (lineNo).ToString(), "=", equalCount.ToString() };
                    dataGridView1.Rows.Add(row);
                    equalCount = 0;
                }

                if (greaterCount > 0)
                {
                    if (operators.Equals(""))
                    {
                        operators = ">";
                    }
                    else
                    {
                        operators += ", >";
                    }
                    row = new string[] { (lineNo).ToString(), ">", greaterCount.ToString() };
                    dataGridView1.Rows.Add(row);
                    greaterCount = 0;
                }

                if (lessCount > 0)
                {
                    if (operators.Equals(""))
                    {
                        operators = "<";
                    }
                    else
                    {
                        operators += ", <";
                    }
                    row = new string[] { (lineNo).ToString(), "<", lessCount.ToString() };
                    dataGridView1.Rows.Add(row);
                    lessCount = 0;
                }

                switch (key)
                {
                    case "int":
                        totalKeywords++;
                        intCount++;
                        string[] value = constant.Split(',');
                        for (int i = 0; i < value.Length; i++)
                        {
                            Match intMatch = intRegex.Match(value[i].TrimEnd(unwanted));
                            if (!intMatch.Success && value[i].Equals(""))
                            {
                                if (comment.Equals(""))
                                    comment = "Incompatible Type";
                                else
                                    comment = comment + "\r\nIncompatible type";
                            }
                        }
                        break;
                    case "for, int":
                        totalKeywords = totalKeywords + 2;
                        intCount++;
                        forCount++;
                        string[] value1 = constant.Split(',');
                        for (int i = 0; i < value1.Length; i++)
                        {
                            Match intMatch = intRegex.Match(value1[i].TrimEnd(unwanted));
                            if (!intMatch.Success)
                            {
                                if (comment.Equals(""))
                                    comment = "Incompatible Type";
                                else
                                    comment = comment + "\r\nIncompatible type";

                            }
                        }
                        break;
                    case "float":
                        totalKeywords++;
                        floatCount++;
                        Match floatMatch = floatRegex.Match(constant);
                        if (!floatMatch.Success && !constant.Equals(""))
                        {
                            if (comment.Equals(""))
                                comment = "Incompatible Type";
                            else
                                comment = comment + "\r\nIncompatible type";
                        }
                        break;
                    case "string":
                        totalKeywords++;
                        stringCount++;
                        Match strMatch = strRegex.Match(word);
                        if (!strMatch.Success && word.Equals(""))
                        {
                            if (comment.Equals(""))
                                comment = "Incompatible Type";
                            else
                                comment = comment + "\r\nIncompatible type";
                        }
                        break;
                    case "bool":
                        totalKeywords++;
                        boolCount++;
                        string[] value2 = constant.Split(',');
                        for (int i = 0; i < value2.Length; i++)
                        {
                            if ((!value2[i].Equals("false") || !value2[i].Equals("false")) && constant.Equals(""))
                            {
                                if (comment.Equals(""))
                                    comment = "Incompatible Type";
                                else
                                    comment = comment + "\r\nIncompatible type";
                            }
                        }
                        break;
                    case "if":
                        totalKeywords++;
                        ifCount++;
                        break;
                }

                if (word.Equals(""))
                {
                    row = new string[] { (lineNo).ToString(), var, key, constant, operators, comment };
                }
                else
                {
                    row = new string[] { (lineNo).ToString(), var, key, word, operators, comment };
                }
                dataGridView2.Rows.Add(row);
            }

            ArrayList keys = new ArrayList();
            string keysToPrint = "";
            if (intCount > 0)
                keys.Add("int");
            if (floatCount > 0)
                keys.Add("float");
            if (stringCount > 0)
                keys.Add("string");
            if (boolCount > 0)
                keys.Add("bool");
            if (ifCount > 0)
                keys.Add("if");
            if (forCount > 0)
                keys.Add("for");

            foreach (var item in keys)
            {
                if (keysToPrint.Equals(""))
                    keysToPrint = item.ToString();
                else
                    keysToPrint += ", " + item.ToString();
            }

            ArrayList OPCount = new ArrayList();
            string OPToPrint = "";
            if (sum > 0)
                OPCount.Add("+");
            if (sub > 0)
                OPCount.Add("-");
            if (mul > 0)
                OPCount.Add("*");
            if (div > 0)
                OPCount.Add("/");
            if (equal > 0)
                OPCount.Add("=");
            if (greater > 0)
                OPCount.Add(">");
            if (less > 0)
                OPCount.Add("<");

            foreach (var item in OPCount)
            {
                if (OPToPrint.Equals(""))
                    OPToPrint = item.ToString();
                else
                    OPToPrint += ", " + item.ToString();
            }

            string identifierList = "";
            foreach (var item in identifierToPrint)
            {
                if (identifierList.Equals(""))
                    identifierList = item.ToString();
                else
                    identifierList += ", " + item.ToString();
            }
            tokens.AppendText("<Keywords> < " + totalKeywords + ": \"" + keysToPrint + "\" >");
            tokens.AppendText("\r\n<Identifiers> <" + totalIdentifiers + ": \"" + identifierList + "\" >");
            tokens.AppendText("\r\n<Operators> < " + totalOperators + ": \"" + OPToPrint + "\" >");
            tokens.AppendText("\r\n<Constants: " + totalConstants + " >");

            file.Close();


            //*************************************** PARSING ********************************************************
            string textFile = File.ReadAllText(@filepath, Encoding.UTF8);
            string[] fileLines = textFile.Split('\r');
            string[] tempArray;
            List<string> words_list = new List<string>();
            for (int w = 0; w < fileLines.Length; w++)
            {
                tempArray = fileLines[w].TrimStart('\n').Split(' ');
                for (int p = 0; p < tempArray.Length; p++)
                {
                    words_list.Add(tempArray[p]);

                }
            }

            stack.AppendText("$ prog");
            // for (int k = 0; k < words_list.Count; k++)
            //{
            do
            {
                string[] stackLines = stack.Text.Split('\n');
                string tempLine = stackLines[stackLines.Length - 1];

                string[] NTarr = tempLine.Split(' ');
                string NT = NTarr[NTarr.Length - 1];

                int flag = 0;

                foreach (KeyValuePair<string, Dictionary<string, string>> itemA in parsingTable)
                {
                    if (itemA.Key.Equals(NT))
                    {
                        flag = 1;
                        foreach (KeyValuePair<string, string> innerItem in itemA.Value)
                        {
                            if (innerItem.Key.Equals(words_list[0]))
                            {
                                if (innerItem.Value.Equals(""))
                                {
                                    MessageBox.Show("Unable to Parse");
                                    return;
                                }
                                else
                                {
                                    string[] keyVal = innerItem.Value.Split(' ');
                                    string newLine = "\n";
                                    if (stackLines.Length > 1)
                                    {
                                        string previousLine = stackLines[stackLines.Length - 1];
                                        string[] PrevArr = previousLine.Split(' ');
                                        for (int y = 0; y < PrevArr.Length - 1; y++)
                                        {
                                            if (y == NTarr.Length - 2)
                                                newLine = newLine + PrevArr[y];
                                            else
                                                newLine = newLine + PrevArr[y] + " ";
                                        }
                                    }
                                    else
                                    {
                                        newLine = newLine + "$";
                                    }


                                    for (int h = keyVal.Length - 1; h >= 0; h--)
                                    {
                                        if (!keyVal[h].Equals("null"))
                                            newLine = newLine + " " + keyVal[h];
                                    }
                                    stack.AppendText(newLine);

                                    break;
                                }
                            }
                        }
                    }
                    else
                    {
                        Match idMatch = identifierRegex.Match(words_list[0]);
                        Match constMatch = constantRegex.Match(words_list[0]);
                        if (idMatch.Success && !keywords.Contains(words_list[0]))
                        {
                            words_list[0] = "id";
                        }
                        if (constMatch.Success || words_list[0].Contains('"'))
                        {
                            words_list[0] = "num";
                        }

                        if (NT.Equals(words_list[0]))
                        {
                            string newLine = "\n";
                            for (int l = 0; l < NTarr.Length - 1; l++)
                            {
                                if (l == NTarr.Length - 2)
                                    newLine = newLine + NTarr[l];
                                else
                                    newLine = newLine + NTarr[l] + " ";

                            }
                            words_list.Remove(NT);
                            stack.AppendText(newLine);
                            break;
                        }


                    }
                }


            } while (!stack.Text.EndsWith("$"));
            //}

            //***************************************** ASSEMBLY LANGUAGE ****************************************************
            string[] opArray = { "+", "-", "/", "*" };
            var opMapping = new Dictionary<string, string>();
            int reg = 0;
            for (int s = 0; s < fileLines.Length; s++)
            {
                string[] parts = fileLines[s].TrimStart('\n').Split(' ');
                if (parts[0].Contains("main") || parts[0].StartsWith("}") || parts[0].StartsWith("if") || parts[0].StartsWith("for") || parts[0].Contains("print"))
                {
                    continue;
                }
                else
                {
                    if (parts.Contains("("))
                    {
                        int[] paraS = parts.Select((b, i) => b == "(" ? i : -1).Where(i => i != -1).ToArray();
                        int[] paraE = parts.Select((b, i) => b == ")" ? i : -1).Where(i => i != -1).ToArray();
                        List<string> newValues = new List<string>();

                        for (int u = 0; u < paraS.Length; u++)
                        {
                            string operand1 = parts[paraS[u] + 1];
                            string operand2 = parts[paraE[u] - 1];
                            string oper = parts[paraS[u] + 2];
                            opMapping.Add("t" + reg, operand1 + " " + oper + " " + operand2);
                            reg++;

                        }

                        int counter = 0;
                        do
                        {
                            string tempKey = "";
                            int start = 0;
                            if (counter > 0)
                            {
                                start = paraS[counter];
                            }

                            for (int h = start; h < paraS[counter]; h++)
                            {
                                newValues.Add(parts[h]);
                            }

                            for (int g = paraS[counter] + 1; g < paraE[counter]; g++)
                            {
                                tempKey = tempKey + parts[g] + " ";
                            }

                            foreach (KeyValuePair<string, string> item in opMapping)
                            {
                                if (item.Value.Equals(tempKey.TrimEnd(' ')))
                                    newValues.Add(item.Key);
                            }

                            if (!(paraS.Length - 1 < counter + 1))
                            {
                                for (int b = paraE[counter] + 1; b < paraS[counter + 1]; b++)
                                {
                                    newValues.Add(parts[b]);
                                }
                            }

                            counter++;
                        } while (counter < paraS.Length);

                        if (!parts[paraE[paraE.Length - 1] + 1].Equals(";"))
                        {
                            for (int w = paraE[paraE.Length - 1] + 1; w < parts.Length; w++)
                            {
                                newValues.Add(parts[w]);
                            }
                        }

                        //Getting number of operators in a line and storing their indexes
                        int[] plus = newValues.Select((b, i) => b == "+" ? i : -1).Where(i => i != -1).ToArray();
                        int[] minus = newValues.Select((b, i) => b == "-" ? i : -1).Where(i => i != -1).ToArray();
                        int[] multi = newValues.Select((b, i) => b == "*" ? i : -1).Where(i => i != -1).ToArray();
                        int[] divide = newValues.Select((b, i) => b == "/" ? i : -1).Where(i => i != -1).ToArray();
                        if (divide.Length > 0)
                        {
                            for (int d1 = 0; d1 < divide.Length; d1++)
                            {
                                string operand1 = newValues[divide[d1] - 1].ToString();
                                string operand2 = newValues[divide[d1] + 1].ToString();
                                Match idMatch = tRegex.Match(operand1);
                                if (!idMatch.Success && !keywords.Contains(operand1))
                                {
                                    var myKey = opMapping.FirstOrDefault(x => x.Value.Contains(operand1)).Key;
                                    if (myKey != null)
                                        operand1 = myKey;
                                }
                                Match idMatch1 = tRegex.Match(operand2);
                                if (!idMatch1.Success && !keywords.Contains(operand2))
                                {
                                    var myKey = opMapping.FirstOrDefault(x => x.Value.Contains(operand2)).Key;
                                    if (myKey != null)
                                        operand2 = myKey;
                                }
                                opMapping.Add("t" + reg, operand1 + " / " + operand2);
                                reg++;
                            }
                        }
                        if (multi.Length > 0)
                        {
                            for (int d1 = 0; d1 < multi.Length; d1++)
                            {
                                string operand1 = newValues[multi[d1] - 1].ToString();
                                string operand2 = newValues[multi[d1] + 1].ToString();
                                Match idMatch = tRegex.Match(operand1);
                                if (!idMatch.Success && !keywords.Contains(operand1))
                                {
                                    var myKey = opMapping.FirstOrDefault(x => x.Value.Contains(operand1)).Key;
                                    if (myKey != null)
                                        operand1 = myKey;
                                }
                                Match idMatch1 = tRegex.Match(operand2);
                                if (!idMatch1.Success && !keywords.Contains(operand2))
                                {
                                    var myKey = opMapping.FirstOrDefault(x => x.Value.Contains(operand2)).Key;
                                    if (myKey != null)
                                        operand2 = myKey;
                                }
                                opMapping.Add("t" + reg, operand1 + " * " + operand2);
                                reg++;
                            }
                        }
                        if (minus.Length > 0)
                        {
                            for (int d1 = 0; d1 < minus.Length; d1++)
                            {
                                string operand1 = newValues[minus[d1] - 1].ToString();
                                string operand2 = newValues[minus[d1] + 1].ToString();
                                Match idMatch = tRegex.Match(operand1);
                                if (!idMatch.Success && !keywords.Contains(operand1))
                                {
                                    var myKey = opMapping.FirstOrDefault(x => x.Value.Contains(operand1)).Key;
                                    if (myKey != null)
                                        operand1 = myKey;
                                }
                                Match idMatch1 = tRegex.Match(operand2);
                                if (!idMatch1.Success && !keywords.Contains(operand2))
                                {
                                    var myKey = opMapping.FirstOrDefault(x => x.Value.Contains(operand2)).Key;
                                    if (myKey != null)
                                        operand2 = myKey;
                                }
                                opMapping.Add("t" + reg, operand1 + " - " + operand2);
                                reg++;
                            }
                        }
                        if (plus.Length > 0)
                        {
                            for (int d1 = 0; d1 < plus.Length; d1++)
                            {
                                string operand1 = newValues[plus[d1] - 1].ToString();
                                string operand2 = newValues[plus[d1] + 1].ToString();
                                Match idMatch = tRegex.Match(operand1);
                                if (!idMatch.Success && !keywords.Contains(operand1))
                                {
                                    var myKey = opMapping.FirstOrDefault(x => x.Value.Contains(operand1)).Key;
                                    if (myKey != null)
                                        operand1 = myKey;
                                }
                                Match idMatch1 = tRegex.Match(operand2);
                                if (!idMatch1.Success && !keywords.Contains(operand2))
                                {
                                    var myKey = opMapping.FirstOrDefault(x => x.Value.Contains(operand2)).Key;
                                    if (myKey != null)
                                        operand2 = myKey;
                                }
                                opMapping.Add("t" + reg, operand1 + " + " + operand2);


                                reg++;
                            }
                        }
                    }
                    else
                    {
                        //Getting number of operators in a line and storing their indexes
                        int[] plus = parts.Select((b, i) => b == "+" ? i : -1).Where(i => i != -1).ToArray();
                        int[] minus = parts.Select((b, i) => b == "-" ? i : -1).Where(i => i != -1).ToArray();
                        int[] multi = parts.Select((b, i) => b == "*" ? i : -1).Where(i => i != -1).ToArray();
                        int[] divide = parts.Select((b, i) => b == "/" ? i : -1).Where(i => i != -1).ToArray();
                        if (divide.Length > 0)
                        {
                            for (int d1 = 0; d1 < divide.Length; d1++)
                            {
                                string operand1 = parts[divide[d1] - 1].ToString();
                                string operand2 = parts[divide[d1] + 1].ToString();
                                Match idMatch = tRegex.Match(operand1);
                                if (!idMatch.Success && !keywords.Contains(operand1))
                                {
                                    var myKey = opMapping.FirstOrDefault(x => x.Value.Contains(operand1)).Key;
                                    if (myKey != null)
                                        operand1 = myKey;
                                }
                                Match idMatch1 = tRegex.Match(operand2);
                                if (!idMatch1.Success && !keywords.Contains(operand2))
                                {
                                    var myKey = opMapping.FirstOrDefault(x => x.Value.Contains(operand2)).Key;
                                    if (myKey != null)
                                        operand2 = myKey;
                                }
                                opMapping.Add("t" + reg, operand1 + " / " + operand2);
                                reg++;
                            }
                        }
                        if (multi.Length > 0)
                        {
                            for (int d1 = 0; d1 < multi.Length; d1++)
                            {
                                string operand1 = parts[multi[d1] - 1].ToString();
                                string operand2 = parts[multi[d1] + 1].ToString();
                                Match idMatch = tRegex.Match(operand1);
                                if (!idMatch.Success && !keywords.Contains(operand1))
                                {
                                    var myKey = opMapping.FirstOrDefault(x => x.Value.Contains(operand1)).Key;
                                    if (myKey != null)
                                        operand1 = myKey;
                                }
                                Match idMatch1 = tRegex.Match(operand2);
                                if (!idMatch1.Success && !keywords.Contains(operand2))
                                {
                                    var myKey = opMapping.FirstOrDefault(x => x.Value.Contains(operand2)).Key;
                                    if (myKey != null)
                                        operand2 = myKey;
                                }
                                opMapping.Add("t" + reg, operand1 + " * " + operand2);
                                reg++;
                            }
                        }
                        if (minus.Length > 0)
                        {
                            for (int d1 = 0; d1 < minus.Length; d1++)
                            {
                                string operand1 = parts[minus[d1] - 1].ToString();
                                string operand2 = parts[minus[d1] + 1].ToString();
                                Match idMatch = tRegex.Match(operand1);
                                if (!idMatch.Success && !keywords.Contains(operand1))
                                {
                                    var myKey = opMapping.FirstOrDefault(x => x.Value.Contains(operand1)).Key;
                                    if (myKey != null)
                                        operand1 = myKey;
                                }
                                Match idMatch1 = tRegex.Match(operand2);
                                if (!idMatch1.Success && !keywords.Contains(operand2))
                                {
                                    var myKey = opMapping.FirstOrDefault(x => x.Value.Contains(operand2)).Key;
                                    if (myKey != null)
                                        operand2 = myKey;
                                }
                                opMapping.Add("t" + reg, operand1 + " - " + operand2);
                                reg++;
                            }
                        }
                        if (plus.Length > 0)
                        {
                            for (int d1 = 0; d1 < plus.Length; d1++)
                            {
                                string operand1 = parts[plus[d1] - 1].ToString();
                                string operand2 = parts[plus[d1] + 1].ToString();
                                Match idMatch = tRegex.Match(operand1);
                                if (!idMatch.Success && !keywords.Contains(operand1))
                                {
                                    var myKey = opMapping.FirstOrDefault(x => x.Value.Contains(operand1)).Key;
                                    if (myKey != null)
                                        operand1 = myKey;
                                }
                                Match idMatch1 = tRegex.Match(operand2);
                                if (!idMatch1.Success && !keywords.Contains(operand2))
                                {
                                    var myKey = opMapping.FirstOrDefault(x => x.Value.Contains(operand2)).Key;
                                    if (myKey != null)
                                        operand2 = myKey;
                                }
                                opMapping.Add("t" + reg, operand1 + " + " + operand2);
                                reg++;
                            }
                        }
                    }
                    if (opMapping.Count > 0)
                        opMapping.Add(parts[0], opMapping.Last().Key);
                }

                foreach (KeyValuePair<string, string> item in opMapping)
                {
                    assemblyCode.AppendText(item.Key + " = " + item.Value + "\n");
                    string[] sep = item.Value.Split(' ');
                    if (sep.Length > 1)
                        row = new string[] { (address).ToString(), sep[1], sep[0], sep[2], item.Key };
                    else
                        row = new string[] { (address).ToString(), "", sep[0], "", item.Key };
                    quad.Rows.Add(row);
                    address++;
                }
                opMapping.Clear();
            }

        }

    }
}
public struct NonTerminal
{
    public int val;
    public int basee;
    public string var;
    public string var2;
    public string dtype;


    public NonTerminal(int v)
    {
        val = int.MinValue;
        basee = int.MinValue;
        dtype = null;
        var = null;
        var2 = null;
    }
}

